# RSTAT PACKAGE #

#' @title Z-values
#' @description Transforms data obtained by measurement into Z-values.
#' @param x data frame of normally scaled variables
#' @param y the data frame of the inversely scaled variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' x <- c(10, 14, 16, 14, 21)
#' y <- c(23, 41, 32, 38, 26)
#' df <- data.frame(x, y)
#' Z <- z_value(x,y)
#' Z
z_value <- function(x, y) {
  ns <- x
  os <- y
  Zns <- scale(ns)
  Zos <- scale(os)*(-1)
  Z <- data.frame(cbind(Zns, Zos))
}

##' @title T-values
#' @description Transforms data obtained by measurement into T-values.
#' @param x data frame of normally scaled variables
#' @param y the data frame of the inversely scaled variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' x <- c(10, 14, 16, 14, 21)
#' y <- c(23, 41, 32, 38, 26)
#' df <- data.frame(x, y)
#' T <- t_value(x,y)
#' T
t_value <- function(x, y) {
  ns <- x
  os <- y
  tns <- scale(ns)*10+50
  tos <- (scale(os)*(-1))*10+50
  T <- data.frame(cbind(tns, tos))
}

#' @title L-values
#' @description Transforms data obtained by measurement into L-values.
#' @param x data frame of normally scaled variables
#' @param y the data frame of the inversely scaled variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' x <- c(10, 14, 16, 14, 21)
#' y <- c(23, 41, 32, 38, 26)
#' df <- data.frame(x, y)
#' L <- l_value(x,y)
#' L
l_value <- function(x, y) {
  ns <- x
  os <- y
  Lns <- scale(ns)*0.83333+3
  Los <- (scale(os)*(-1))*0.83333+3
  L <- data.frame(cbind(Lns, Los))
}

#' @title Onedimensional grouping of qualitative data
#' @description Groups qualitative variable and calculates observed and expected absolute and relative frequencies.
#' @param x qualitative variable
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' SPOL <- c("m", "m", "ž", "m", "ž")
#' DOB <- c(23, 41, 32, 38, 26)
#' df <- data.frame(SPOL, DOB)
#' tf <- tab_frequency(df$SPOL)
#' tf
tab_frequency <- function(x) {
  fo <- table(x)
  k <- length(fo)
  tf <- as.data.frame(fo)
  colnames(tf) <- c("GROUP", "F")
  tf$RF <- tf$F/sum(tf$F)*100
  tf$FO <- sum(tf$F)/k
  tf$RO <- tf$FO/sum(tf$FO)*100
  colnames(tf) <- c("GROUP", "Observed Frequency", "Observed Percent", "Expected Frequency", "Expected Percent")
  tf
}

#' @title Chi square goodness of fit test
#' @description Tests the hypothesis about the agreement between observed and expected frequencies of a uniform distribution
#' @param x qualitative variable
#' @return text
#' @export
#' @examples
#' library(rstatpackage)
#' SPOL <- c("m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž", "m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž")
#' chi_results <- chi_square_goodness_fit(SPOL)
#' chi_results
chi_square_goodness_fit <- function(x) {
  cft <- table(x)
  ctf <- data.frame(cft)
  hi <- chisq.test(ctf[2])
  chi <- round(hi[["statistic"]][["X-squared"]], digits = 3)
  df <- hi[["parameter"]][["df"]]
  p <- round(hi[["p.value"]], digits = 4)
  chi_results <- paste("Chi-square = ", chi,"; df = ", df, "; p =", p)
}

#' @title Twodimensional grouping of qualitative data - frequencies
#' @description Groups data of two qualitative variables and calculates frequencies
#' @param x qualitative variable
#' @param y qualitative variable
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' SPOL <- c("m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž", "m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž")
#' KRAJ <- c("g", "p", "p", "g", "p","p", "p", "g", "p", "g", "p", "g", "g", "p", "p","p", "g", "g", "p", "p")
#' chi_results <- cross_tab_f(SPOL, KRAJ)
#' chi_results
cross_tab_f <- function(x, y) {
  ctf <- gmodels::CrossTable(x, y, chisq = T)
  ctf <- as.data.frame.matrix(ctf[["chisq"]][["observed"]])
  ctf$Total = rowSums(ctf[,])
  k <- length(ctf$Total)+1
  ctf <- rbind(ctf, colSums(ctf[,]))
  row.names(ctf)[k] <- "Total"
  ctf
}

#' @title Twodimensional grouping of qualitative data - percentages
#' @description Groups data of two qualitative variables and calculates relative frequencies
#' @param x qualitative variable
#' @param y qualitative variable
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' SPOL <- c("m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž", "m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž")
#' KRAJ <- c("g", "p", "p", "g", "p","p", "p", "g", "p", "g", "p", "g", "g", "p", "p","p", "g", "g", "p", "p")
#' chi_results <- cross_tab_p(SPOL, KRAJ)
#' chi_results
cross_tab_p <- function(x, y) {
  ctfp <- gmodels::CrossTable(x, y, chisq = T)
  ctfp <- round(as.data.frame.matrix(ctfp$prop.row)*100, digits = 2)
  ctfp$Total <-  round(rowSums(ctfp[,]), digits = 0)
  ctfp
}

#' @title Twodimensional clustering of qualitative data - expected frequencies
#' @description Groups the data of two qualitative variables and calculates the expected frequencies
#' @param x qualitative variable
#' @param y qualitative variable
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' SPOL <- c("m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž", "m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž")
#' KRAJ <- c("g", "p", "p", "g", "p","p", "p", "g", "p", "g", "p", "g", "g", "p", "p","p", "g", "g", "p", "p")
#' chi_results <- cross_tab_e(SPOL, KRAJ)
#' chi_results
cross_tab_e <- function(x, y) {
  ctfe <-  gmodels::CrossTable(x, y, chisq = T)
  ctfe <- round(as.data.frame.matrix(ctfe[["chisq"]][["expected"]]), digits = 2)
  ctfe$Total = round(rowSums(ctfe[,]), digits = 0)
  k <- length(ctfe$Total)+1
  ctfe <- rbind(ctfe, colSums(ctfe[,]))
  row.names(ctfe)[k] <- "Total"
  ctfe
}

#' @title Chi square test of independence
#' @description Tests the hypothesis of independence of two qualitative variables
#' @param x qualitative variable
#' @param y qualitative variable
#' @return text
#' @export
#' @examples
#' library(rstatpackage)
#' SPOL <- c("m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž", "m", "m", "ž", "m", "ž","m", "m", "ž", "m", "ž")
#' KRAJ <- c("g", "p", "p", "g", "p","p", "p", "g", "p", "g", "p", "g", "g", "p", "p","p", "g", "g", "p", "p")
#' chi_results <- chi_square_indepence(SPOL, KRAJ)
#' chi_results
chi_square_indepence <- function(x, y) {
  chit <- gmodels::CrossTable(x, y, chisq = T)
  chi <- round(chit[["chisq"]][["statistic"]][["X-squared"]], digits = 3)
  df <- round(chit[["chisq"]][["parameter"]][["df"]], digits = 3)
  p <- round(chit[["chisq"]][["p.value"]], digits = 3)
  chi_results_ind <- paste("Chi-square = ", chi,"; df = ", df, "; p =", p)
}


#' @title McNemar's chi square test
#' @description Tests a hypothesis about the difference between two measurements
#' @param x qualitative variable
#' @param y qualitative variable
#' @return text
#' @export
#' @examples
#' library(rstatpackage)
#' PRIJE <- c("da", "da", "ne", "ne", "ne","da", "da", "da", "ne", "ne", "ne", "ne", "da", "da", "ne","ne", "ne")
#' NAKON <- c("da", "da", "ne", "da", "ne","da", "da", "da", "da", "ne", "da", "ne", "ne", "da", "da","ne", "d")
#' chi_results <- chi_square_indepence(SPOL, KRAJ)
#' chi_results
mcnemar_test <- function(x ,y) {
  mcchit <- gmodels::CrossTable(x, y, mcnemar = T)
  mcchi <- round(mcchit[["mcnemar"]][["statistic"]][["McNemar's chi-squared"]], digits = 3)
  mcdf <- round(mcchit[["mcnemar"]][["parameter"]][["df"]], digits = 3)
  mcp <- round(mcchit[["mcnemar"]][["p.value"]], digits = 3)
  mcchi.cor <- round(mcchit[["mcnemar.corr"]][["statistic"]][["McNemar's chi-squared"]], digits = 3)
  mcdf.cor <- round(mcchit[["mcnemar.corr"]][["parameter"]][["df"]], digits = 3)
  mcp.cor <- round(mcchit[["mcnemar.corr"]][["p.value"]], digits = 3)
  mcnemar_results <- paste("McNemar's Chi-square = ", mcchi,"; df = ", mcdf, "; p =", mcp, "</br>",
                           "McNemar's Chi-square with continuity correction = ", mcchi.cor,"; df = ", mcdf.cor, "; p =", mcp.cor)
}

#' @title Grouping quantitative data
#' @description Groups a quantitative variable and calculates absolute and relative frequencies and cumulative absolute and relative frequencies
#' @param x quantitative variable
#' @param y class number
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' br <- 5
#' TV <- c(185,178,165,184,178,195,186,183,179,156,196,166,159,178,179,175,186,196,194,198,185,182,199,152,157)
#' df <- dist_freq(TV,br)
#' df
dist_freq <- function(x, y) {
  ir <- (max(x) - min(x))/(y-1)
  ir2 <- ir/2
  breaks <- round(seq(min(x)-ir2, max(x)+ir2, by=ir), digits = 2)
  f.cut = cut(x, breaks, right=TRUE)
  d.freq = table(f.cut)
  df <- cbind.data.frame(d.freq)
  colnames(df) <- c("Bins", "F")
  df$RF <- round(df$F/sum(df$F)*100, digits = 2)
  df$CF <- cumsum(df$F)
  df$RCF  <- round(cumsum(df$RF), digits = 2)
  df <- cbind.data.frame(df)
  colnames(df) <- c("Bins", "Frequency", "Percent", "Cumulative","Cumulative Percent")
  df
}

#' @title Descriptive indicators
#' @description Calculates descriptive indicators (arithmetic mean, median, standard deviation, coefficient of variability, minimum and maximum range of results, skewnws and kurtosis)
#' @param x data frame of quantitative variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA |> select_if(is.numeric)
#' des_par <-descriptive_parameters(x)
#' des_par
descriptive_parameters <- function(x) {
  dp <-  psych::describe(x)
  kv <- dp$sd/dp$mean*100
  dp <- cbind(dp,kv)
  dp <- dp[c(3, 5, 4, 14, 8, 9, 10, 11, 12)]
  colnames(dp) <- c("MEAN", "MEDIAN", "SD", "CV", "MIN", "MAX", "RANGE", "SKEW", "KURT")
  dp
}

#' @title Test for normality of distribution
#' @description Tests the hypothesis of normality of the empirical distribution
#' @param x quantitative variable
#' @return text
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA |> select_if(is.numeric)
#' test_norm <-test_normality(x$ATV)
#' test_norm
test_normality <- function(x) {
  ks <- ks.test(x, "pnorm", mean=mean(x), sd=sd(x))
  D <- round(ks[["statistic"]][["D"]], digits = 3)
  pks <- round(ks[["p.value"]], digits = 3)
  lt <- nortest::lillie.test(x)
  Dlks <- round(lt[["statistic"]][["D"]], digits = 3)
  plks <- round(lt[["p.value"]], digits = 3)
  ad <- nortest::ad.test(x)
  A <- round(ad[["statistic"]][["A"]], digits = 3)
  pa <- round(ad[["p.value"]], digits = 3)
  sf <- nortest::sf.test(x)
  Wsf <- round(sf[["statistic"]][["W"]], digits = 3)
  psf <- round(sf[["p.value"]], digits = 3)
  sw <- shapiro.test(x)
  W <- round(sw$statistic, digits = 3)
  psw <- round(sw$p.value, digits = 3)
  test_norm <- paste(
    "Kolmogorov-Smirnov test: D = ", D,"; p = ", pks, "</br>",
    "Lilliefors test: D = ", Dlks,"; p = ", plks, "</br>",
    "Anderson-Darling test: A = ", A,"; p = ", pa, "</br>",
    "Shapiro-Francia test: W = ", Wsf,"; p = ", psf, "</br>",
    "Shapiro-Wilk test: W = ", W,"; p = ", psw
  )
}


#' @title Estimation of the arithmetic mean of pollulation
#' @description Estimate of the interval in which the arithmetic mean of the population is located
#' @param x quantitative variable
#' @param n number (sample size)
#' @param p number(stat loop error)
#' @return text
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA |> select_if(is.numeric)
#' n <- nrow(x)
#' p <- 0.05
#' CI_pop_mean <-CI_population_mean(x$ATV, n, p)
#' CI_pop_mean
CI_population_mean <- function(x, n, p) {
  as <- round(mean(x), digits = 2)
  sd <- round(sd(x), digits = 2)
  se <- round(sd/sqrt(n), digits = 2)
  t <- round(qt(p/2, n, lower.tail = F), digits = 2)
  x1 <- round(as-t*se, digits = 2)
  x2 <- round(as+t*se, digits = 2)
  CI_pop_mean <- paste("Sample Size =", n, "</br>",
                       "Sample Mean =", as, "</br>",
                       "Sample Standard Deviation =", sd, "</br>",
                       "Standard Error of the Mean =", se, "</br>",
                       "p =", p, "</br>",
                       "t =", t, "</br>",
                       "-----------------------------------------------------", "</br>",
                       "<b>", x1, "~ Population Mean ~", x2
  )
}


#' @title t - test for independent samples
#' @description Checks the hypothesis whether the difference between the arithmetic means of two samples is statistically significant with an error of p
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(car)
#' library(plyr)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$KRAJ
#' titt <-t_test_independent(x, g)
#' titt
t_test_independent <- function(x, g) {
  VFDF <- cbind.data.frame(g, x)
  vn <- variable.names(x)
  m <- ncol(x)
  n <- nrow(x)
  j <- 0
  lt <- c(m)
  lmat <- matrix(data=1:2*m, nrow = m, ncol = 2)
  for (j in 1:m) {
    lt[j] <- list(car::leveneTest (x[,j] ~ g, center=mean))
    lmat[j,1] <- lt[[j]]$`F value`[1]
    lmat[j,2] <- lt[[j]]$`Pr(>F)`[1]
  }
  names(lt) <- vn
  ldf <- data.frame(lmat)
  row.names(ldf) <- vn
  ldf <- round(ldf, digits = 3)
  t_rez <- lapply(VFDF[,vn], function(x) t.test(x ~ g, var.equal = TRUE))
  mean <- data.frame(mean = sapply(t_rez, getElement, name = "estimate"))
  ser <- data.frame(ser = sapply(t_rez, getElement, name = "stderr"))
  tt <- data.frame(t = sapply(t_rez, getElement, name = "statistic"))
  tdf <- data.frame(df = sapply(t_rez, getElement, name = "parameter"))
  tp <- data.frame(p = sapply(t_rez, getElement, name = "p.value"))
  tconf.int <- data.frame(conf.int = sapply(t_rez, getElement, name = "conf.int"))
  tmean <- t(mean)
  ci <- t(tconf.int)
  rez <- cbind.data.frame(tmean, ser, abs(tt), tdf, tp, ci)
  d <- lapply(VFDF[,vn], function(x) lsr::cohensD(x ~ g))
  df <- plyr::ldply (d, data.frame)
  df <- round(df[[2]], digits = 3)
  tt_rez <- round(rez, digits = 3)
  titt <- cbind.data.frame(tt_rez, ldf, df)
  colnames(titt) <- c("MEAN1", "MEAN2", "SED", "T", "DF", "P", "CI-95%", "CI+95%", "Levene's F", "P", "Cohen's D")
  row.names(titt) <- c(vn)
  titt
}

#' @title t - test for dependent samples
#' @description Checks the hypothesis whether the difference between the arithmetic means of two measurements is statistically significant with an error of p
#' @param data data frame (data table)
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two modalities (measurements)
#' @return dataframe
#' @export
#' @examples
#'library(rstatpackage)
#'library(dplyr)
#'library(lsr)
#'library(plyr)
#'x <- DATA2 |> select(ATT, MPOTR, MSDM, MKUS)
#'g <- DATA2$MJERENJE
#'tdtt <- t_test_paired(x, g)
#'tdtt
t_test_paired <- function(x, g){
  VFDF <- cbind.data.frame(g, x)
  vn <- variable.names(x)
  m <- ncol(x)
  n <- nrow(x)
  t_rez <- lapply(VFDF[,vn], function(x) t.test(x ~ g,  paired = TRUE, var.equal = TRUE))
  chd <- lapply(VFDF[,vn], function(x) lsr::cohensD(x ~ g, method = "paired"))
  df <- plyr::ldply(chd, data.frame)
  rmean <- data.frame(mean = sapply(t_rez, getElement, name = "estimate"))
  ser <- data.frame(ser = sapply(t_rez, getElement, name = "stderr"))
  tt <- data.frame(t = sapply(t_rez, getElement, name = "statistic"))
  tdf <- data.frame(df = sapply(t_rez, getElement, name = "parameter"))
  tp <- data.frame(p = sapply(t_rez, getElement, name = "p.value"))
  tconf.int <- data.frame(conf.int = sapply(t_rez, getElement, name = "conf.int"))
  ci <- t(tconf.int)
  tdtt <- cbind.data.frame(rmean, ser, abs(tt), tdf, tp, ci, df[2])
  colnames(tdtt) <- c("DIFF", "SED", "T", "DF", "P", "CI-95%", "CI+95%", "Cohen's D")
  row.names(tdtt) <- c(vn)
  tdtt <- round(tdtt, digits = 3)
}

#' @title One-Way ANOVA
#' @description Tests the hypothesis whether the difference between the arithmetic means of two or more samples is statistically significant with an error of p
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two or more modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(car)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$KRAJ
#' arez <-anova_one_way(x, g)
#' arez
anova_one_way <- function(x, g) {
  VFDF <- cbind.data.frame(g, x)
  vn <- variable.names(x)
  m <- ncol(x)
  j <- 0
  la <- c(m)
  lmat <- matrix(data=1:2*m, nrow = m, ncol = 2)
  for (j in 1:m) {
    la[j] <- list(car::leveneTest (x[,j] ~ g, center=mean))
    lmat[j,1] <- la[[j]]$`F value`[1]
    lmat[j,2] <- la[[j]]$`Pr(>F)`[1]
  }
  ladf <- data.frame(lmat)
  X <- as.matrix(x)
  Y <- as.matrix(g)
  a_rez <- lapply(VFDF[,vn], function(X) oneway.test(X ~ Y, var.equal = TRUE))
  aF <- data.frame(F = sapply(a_rez, getElement, name = "statistic"))
  adf<- data.frame(df1 = sapply(a_rez, getElement, name = "parameter"))
  ap <- data.frame(p = sapply(a_rez, getElement, name = "p.value"))
  arez <- cbind.data.frame(round(aF, digits = 3), t(adf), round(ap, digits = 3), round(ladf, digits = 3))
  colnames(arez) <- c("Fisher's F", "DF1", "DF2", "Fisher's p","Levene's F", "Levene's p")
  row.names(arez) <- c(vn)
  arez
}

#' @title Multiple correlation
#' @description Calculates multiple correlation and tests its statistical significance
#' @param x the data frame of the predictor variables
#' @param y the criterion variable
#' @return text
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA |> select(ATV, ATT, AOP, ANN)
#' y <- DATA$MVIS
#' ro <- reg_ro(x,y)
#' ro
reg_ro <- function(x, y){
  X <- as.matrix(x)
  Y <- as.matrix(y)
  m <- ncol(X)+1
  n <- nrow(X)
  B0 <- rep.int(1, n)
  Xi <- cbind(B0, X)
  XTXi <- t(Xi) %*% Xi
  XTY <- t(Xi) %*% Y
  b <- solve(XTXi) %*% XTY
  Yp <- Xi %*% b
  e <- Y - Yp
  se <- round(sqrt(sum(e*e)/(n-m)), digits = 2)
  pss <- sum((Yp-mean(Yp))**2)
  rss <- sum((e-mean(e))**2)
  ro2 <- pss/(pss+rss)
  ro <- round(sqrt(ro2), digits = 2)
  dfp <- m-1
  dfe <- n-m
  Fval <- (pss/dfp)/(rss/dfe)
  pf <- pf(Fval, dfp, dfe, lower.tail = FALSE)
  dw <- car::durbinWatsonTest(lm(Y ~ X))
  paste("RO =", round(ro, digits = 3),
        "; RO2 =", round(ro2, digits = 3),
        "; SEE =", round(se, digits = 2),
        "; F-value =", round(Fval, digits = 3),
        "; p-value  =", round(pf, digits = 4), "</br>",
        "Autocorrelation =", round(dw$r, digits = 3),
        "; Durbin-Watson d =", round(dw$dw, digits = 3),
        "; p =", round(dw$p, digits = 4)
  )
}

#' @title Regression parameters
#' @description Calculates regression parameters and tests their statistical significance
#' @param x the data frame of the predictor variables
#' @param y the criterion variable
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA |> select(ATV, ATT, AOP, ANN)
#' y <- DATA$MVIS
#' reg_par <- reg_parameters(x,y)
#' reg_par
reg_parameters <- function(x, y){
  X <- as.matrix(x)
  Y <- as.matrix(y)
  m <- ncol(X)+1
  n <- nrow(X)
  XY <- cbind(X,Y)
  Z <- scale(X)
  K <- scale(Y)
  ZK <- round(cbind(Z,K), digits = 2)
  Rxy <- cor(XY)
  R <- cor(X)
  B0 <- rep.int(1, n)
  Xi <- cbind(B0,X)
  XTXi <- t(Xi) %*% Xi
  XTY <- t(Xi) %*% Y
  b <- solve(XTXi) %*% XTY
  r1 <- (t(Z) %*% K)/(n-1)
  r <- rbind(0, r1)
  beta1 <- solve(R) %*% r1
  beta <- rbind(0,beta1)
  S2 <- 1/diag(solve(R))
  s2 <- data.frame(S2)
  s2<- rbind(0,s2)
  S2xy <- 1/diag(solve(Rxy))
  Sxy <- sqrt(S2xy)
  Pr <- diag(Sxy) %*% solve(Rxy) %*% diag(Sxy)
  pr <- (Pr[,m]*-1)
  pr <- pr[1:m-1]
  pr <- data.frame(pr)
  pr <- rbind(0,pr)
  p <- beta*r
  Yp <- Xi %*% b
  e <- Y - Yp
  se <- round(sqrt(sum(e*e)/(n-m)), digits = 2)
  wjj <- solve(XTXi)
  diagwjj <- diag(wjj)
  seb <- se*sqrt(diagwjj)
  tb <- abs(b/seb)
  df <- n-m
  pval <- c()
  for (a in 0:m) {pval[a] <- c(2*(pt(abs(tb[a,1]), df, lower.tail = FALSE)))}
  tb <- data.frame(tb)
  pval <- data.frame(pval)
  reg_par <- cbind(b, seb, beta, pr, r, p, s2, tb, pval)
  colnames(reg_par) <- c("B","SE(B)", "Beta", "Part_R", "R","P", "Tolerance", "t", "p")
  reg_par
}


#' @title Regression scores
#' @description Calculates regression scores
#' @param x the data frame of the predictor variables
#' @param y the criterion variable
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA |> select(ATV, ATT, AOP, ANN)
#' y <- DATA$MVIS
#' reg_score <- reg_scores(x,y)
#' reg_score
reg_scores <- function(x,y){
  X <- as.matrix(x)
  Y <- as.matrix(y)
  n <- nrow(X)
  B0 <- rep.int(1, n)
  Xi <- cbind(B0,X)
  XTXi <- t(Xi) %*% Xi
  XTY <- t(Xi) %*% Y
  b <- solve(XTXi) %*% XTY
  Yp <- Xi %*% b
  e <- Y - Yp
  reg_score <- cbind(Y, Yp, e)
  colnames(reg_score) <- c("Observed Value","Predicted Value", "Residual Values")
  reg_score
}

#' @title Factor analysis (principal components method) - eigenvalues
#' @description Calculates the eigenvalues of the correlation matrix
#' @param x data frame of manifest variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA3 |> select_if(is.numeric)
#' lamda <- fac_lamda(x)
#' lamda
fac_lamda <- function(x){
  mm <- ncol(x)
  fit <- psych::principal(x)
  Eigenvalue <- fit$values
  Cum.Eign <- cumsum(Eigenvalue)
  Percentage <- Eigenvalue/sum(Eigenvalue)*100
  Cum.Per <- cumsum(Percentage)
  lamda <- cbind(Eigenvalue, Cum.Eign, Percentage, Cum.Per)
  rownames(lamda) <- 1:mm
  lamda
}

#' @title Factor analysis (principal component method) - SSMC
#' @description Calculates the sum of squares of multiple correlations of manifest variables
#' @param x data frame of manifest variables
#' @return text
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA3 |> select_if(is.numeric)
#' ssmc <- fac_ssmc(x)
#' ssmc
fac_ssmc <- function(x){
  mm <- ncol(x)
  R <- cor(x)
  SMC <- 1-(1/diag(solve(R)))
  j <- rep(1,mm)
  SSMC<- SMC %*% j
  ssmc <- SSMC[1,1]
  paste("Sum of Squares Multiple Correlation (SSMC) =", round(ssmc, digits = 2))
}


#' @title Factor analysis (principal components method) - assembly matrix
#' @description Calculates the matrix A of parallel projections of manifest variables onto rotated factors
#' @param x data frame of manifest variables
#' @param k number of significant factors
#' @param r type of rotation (none, varimax, quartimax, oblimin, promax)
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA3 |> select_if(is.numeric)
#' k <- 3
#' r <- "oblimin"
#' A <- fac_pattern(x, k, r)
#' A
fac_pattern <-function(x, k, r){
  mm <- ncol(x)
  fnames <- paste0("F", 1:mm)
  fit <- psych::principal(x, nfactors=k, rotate=r)
  Complexity <- fit$complexity
  A <- fit$loadings
  critical.a1 <- 0.6
  critical.a2 <- -0.6
  colnames(A) <- fnames[1:k]
  A <- cbind(A, Complexity)
  A
}

#' @title Factor analysis (principal component method) - structure matrix
#' @description Calculates the matrix F of orthogonal projections (correlations) of manifest variables onto rotated factors
#' @param x data frame of manifest variables
#' @param k number of significant factors
#' @param r type of rotation (none, varimax, quartimax, oblimin, promax)
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA3 |> select_if(is.numeric)
#' k <- 3
#' r <- "oblimin"
#' F <- fac_structure(x, k, r)
#' F
fac_structure <- function(x, k, r){
  mm <- ncol(x)
  fnames <- paste0("F", 1:mm)
  fit <- psych::principal(x, nfactors=k, rotate=r)
  Communality <- fit$communality
  FF <- fit$Structure
  critical.f1 <- 0.6
  critical.f2 <- -0.6
  colnames(FF) <- fnames[1:k]
  F <- cbind(FF, Communality)
  F
}

#' @title Factor analysis (principal component method) - correlations between factors
#' @description Calculates matrix M of correlations between rotated factors
#' @param x data frame of manifest variables
#' @param k number of significant factors
#' @param r type of rotation (none, varimax, quartimax, oblimin, promax)
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA3 |> select_if(is.numeric)
#' k <- 3
#' r <- "oblimin"
#' M <- fac_correlation(x, k, r)
#' M
fac_correlation <- function(x, k, r){
  mm <- ncol(x)
  fnames <- paste0("F", 1:mm)
  fit <- psych::principal(x, nfactors=k, rotate=r)
  M <- cor(fit$scores)
  colnames(M) <- fnames[1:k]
  rownames(M) <- fnames[1:k]
  M
}

#' Factor Analysis - Factor Scores
#' @title Factor analysis (principal component method) - factor scores
#' @description Calculates the matrix of factor scores of rotated factors
#' @param x data frame of manifest variables
#' @param k number of significant factors
#' @param r type of rotation (none, varimax, quartimax, oblimin, promax)
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' x <- DATA3 |> select_if(is.numeric)
#' k <- 3
#' r <- "oblimin"
#' FS <- fac_scores(x, k, r)
#' FS
fac_scores <- function(x, k, r){
  mm <- ncol(x)
  fnames <- paste0("F", 1:mm)
  fit <- psych::principal(x, nfactors=k, rotate=r)
  FS <- fit$scores
  fnames <- paste0("F", 1:mm)
  colnames(FS) <- fnames[1:k]
  FS
}

#' @title Canonical analysis - canonical correlations
#' @description Calculates the canonical correlation matrix and tests their statistical significance
#' @param x the data frame of the variables of the first set
#' @param y the data frame of the second set's variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(yacca)
#' x <- DATA3 |> select(ONT, OUZ, NEB)
#' y <- DATA3 |> select(SKL, CUC, TRB, SDM, BML, T20m)
#' rc <- can_cor(x, y)
#' rc
can_cor <-function(x, y) {
  m1 <- ncol(x)
  m2 <- ncol(y)
  mm <- m1+m1
  fnames <- paste0("CF", 1:mm)
  if (m1<=m2) {kk=m1} else {kk=m2}
  if (m1>=m2) {rcca <- yacca::cca (x, y, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  else {rcca <- yacca::cca (y, x, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  p <- pchisq(rcca$chisq, rcca$df, lower.tail = FALSE)
  rc <- cbind.data.frame(fnames[1:kk], round(rcca$corr, digits = 3), round(rcca$chisq, digits = 3), rcca$df, round(p, digits = 3))
  rc <- rc[c(1,2,3,4,5)]
  colnames(rc) <- c("CF", "Rc", "Chi-sq.","df", "p-level")
  rc <- data.frame(rc[,-1], row.names=rc[,1])
}

#' @title Canonical analysis - structure of canonical factors of the first set
#' @description Calculates the correlation matrix of the variables of the first set and the canonical factors of the first set
#' @param x the data frame of the variables of the first set
#' @param y the data frame of the second set's variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(yacca)
#' x <- DATA3 |> select(ONT, OUZ, NEB)
#' y <- DATA3 |> select(SKL, CUC, TRB, SDM, BML, T20m)
#' can_struc1 <- can_structure1(x, y)
#' can_struc1
can_structure1 <- function(x, y){
  m1 <- ncol(x)
  m2 <- ncol(y)
  mm <- m1+m1
  fnames <- paste0("CF", 1:mm)
  if (m1<=m2) {kk=m1} else {kk=m2}
  if (m1>=m2) {rcca <- yacca::cca(x, y, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  else {rcca<-  yacca::cca(y, x, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  if (m1>=m2) {F1 <- round(rcca$xstructcorr, digits = 3)} else {F1 <- round(rcca$ystructcorr, digits = 3)}
  colnames(F1) <- fnames[1:kk]
  F1
}

#' @title Canonical analysis - structure of canonical factors of the second set
#' @description Calculates the correlation matrix of the variables of the second set and the canonical factors of the second set
#' @param x the data frame of the variables of the first set
#' @param y the data frame of the second set's variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(yacca)
#' x <- DATA3 |> select(ONT, OUZ, NEB)
#' y <- DATA3 |> select(SKL, CUC, TRB, SDM, BML, T20m)
#' can_struc2 <- can_structure2(x, y)
#' can_struc2
can_structure2 <- function(x, y){
  m1 <- ncol(x)
  m2 <- ncol(y)
  mm <- m1+m1
  fnames <- paste0("CF", 1:mm)
  if (m1<=m2) {kk=m1} else {kk=m2}
  if (m1>=m2) {rcca <- yacca::cca(x, y, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  else {rcca <- yacca::cca (y, x, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  if (m1>=m2) {F2 <- round(rcca$ystructcorr, digits = 3)} else {F2 <- round(rcca$xstructcorr, digits = 3)}
  colnames(F2) <- fnames[1:kk]
  F2
}

#' @title Canonical analysis - canonical scores of the first canonical factor
#' @description Computes the entity score matrix on the first canonical factor
#' @param x the data frame of the variables of the first set
#' @param y the data frame of the second set's variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(yacca)
#' x <- DATA3 |> select(ONT, OUZ, NEB)
#' y <- DATA3 |> select(SKL, CUC, TRB, SDM, BML, T20m)
#' can_fac1 <- can_factor1(x, y)
#' can_fac1

can_factor1 <- function(x, y){
  m1 <- ncol(x)
  m2 <- ncol(y)
  mm <- m1+m1
  fnames <- paste0("CF", 1:mm)
  if (m1<=m2) {kk=m1} else {kk=m2}
  if (m1>=m2) {rcca <- yacca::cca (x, y, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  else {rcca <- yacca::cca (y, x, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  if (m1>=m2) {CF1 <- round(rcca$canvarx, digits = 3)} else {CF1 <- round(rcca$canvary, digits = 3)}
  colnames(CF1) <- fnames[1:kk]
  CF1
}

#' @title Canonical analysis - canonical scores of the second canonical factor
#' @description Computes the entity score matrix on the second canonical factor
#' @param x the data frame of the variables of the first set
#' @param y the data frame of the second set's variables
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(yacca)
#' x <- DATA3 |> select(ONT, OUZ, NEB)
#' y <- DATA3 |> select(SKL, CUC, TRB, SDM, BML, T20m)
#' can_fac2 <- can_factor2(x, y)
#' can_fac2
can_factor2 <- function(x, y){
  m1 <- ncol(x)
  m2 <- ncol(y)
  mm <- m1+m1
  fnames <- paste0("CF", 1:mm)
  if (m1<=m2) {kk=m1} else {kk=m2}
  if (m1>=m2) {rcca <- yacca::cca (x, y, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  else {rcca <- yacca::cca (y, x, xscale = TRUE, yscale = TRUE, standardize.scores = TRUE)}
  if (m1>=m2) {CF2 <- round(rcca$canvary, digits = 3)} else {CF2 <- round(rcca$canvarx, digits = 3)}
  colnames(CF2) <- fnames[1:kk]
  CF2
}

#' @title Discriminant analysis - parameters of discriminant functions
#' @description Calculates the parameters of discrimination functions and tests their statistical significance
#' @param data data frame (data table)
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two or more modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(candisc)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$KRAJ
#' df <-disc_df(DATA, x, g)
#' df
disc_df <- function(data, x, g) {
  X <- as.matrix(x)
  G <- as.matrix(g)
  var_disc <- lm(X ~ G, data = data)
  cd_candisc <- candisc::candisc(var_disc, data = data)
  w <- candisc::Wilks(cd_candisc)
  k <- cd_candisc$ndim
  fnames <- paste0("DF", 1:k)
  Eigenval <- round(cd_candisc$eigenvalues, digits = 3)
  Canonical_corr <- round(sqrt((cd_candisc$canrsq)), digits = 3)
  Wilks_lam <- round(w$`LR test stat`, digits = 3)
  F_aprox <- round(w$`approx F`, digits = 3)
  df1 <- w$numDF
  df2 <- w$denDF
  p_value <- round(w$`Pr(> F)`, digits = 3)
  df <- cbind(fnames, Eigenval, Canonical_corr, Wilks_lam, F_aprox, df1, df2, p_value)
  df <- data.frame(df)
  colnames(df) <- c("DF", "Eigenvalue", "Canonical R", "Wilks' Lambda","aprox. F", "df1", "df2", "p level")
  df <- df[1:k,]
  df
}

#' @title Discriminant analysis - structure of discriminant functions
#' @description Calculates the parameters of the structure of discrimination functions (correlations of variables with discrimination functions)
#' @param data data frame (data table)
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two or more modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(candisc)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$RAZRED
#' disc_struc <-disc_structure(DATA, x, g)
#' disc_struc
disc_structure <- function(data, x, g) {
  X <- as.matrix(x)
  G <- as.matrix(g)
  m <- ncol(x)
  dfnames <- paste0("DF", 1:m)
  var_disc <- lm(X ~ G, data = data)
  cd_candisc <- candisc::candisc(var_disc, data = data)
  k <- cd_candisc$ndim
  sdf <- round(cd_candisc$structure, digits = 3)
  sdf <- data.frame (sdf)
  colnames(sdf) <- dfnames[1:k]
  sdf
}

#' @title Discriminant analysis - centroids
#' @description Calculates the centroid
#' @param data data frame (data table)
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two or more modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(candisc)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$RAZRED
#' disc_cent <- disc_centroids (DATA, x, g)
#' disc_cent
disc_centroids <- function(data, x, g){
  X <- as.matrix(x)
  G <- as.matrix(g)
  m <- ncol(x)
  dfnames <- paste0("DF", 1:m)
  var_disc <- stats::lm(X ~ G, data = data)
  cd_candisc <- candisc::candisc(var_disc, data = data)
  f <- table(cd_candisc$factors)
  k <- cd_candisc$ndim
  cg <- round(cd_candisc$means, digits = 3)
  cg <- data.frame(cg)
  cg <- cbind.data.frame(f, cg)
  cg <- data.frame(cg[,-1], row.names=cg[,1])
  colnames(cg) <- c(names(g), "FREQ.", dfnames[1:k])
  cg
}


#' @title Discriminant analysis - classification matrix (frequencies)
#' @description Computes the classification matrix
#' @param data data frame (data table)
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two or more modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(candisc)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$RAZRED
#' disc_clasf <- disc_clas_f (DATA, x, g)
#' disc_clasf
disc_clas_f <- function(data, x, g){
  X <- as.matrix(x)
  var_disc <- MASS::lda(g ~ X, data)
  predict <- predict(var_disc)
  predict <- predict$class
  ctf <- gmodels::CrossTable(predict, g)
  ctf <- as.data.frame.matrix(t(ctf$t))
  ctf$Total = rowSums(ctf[,])
  ctf
}


#' @title Discriminant analysis - classification matrix (percentages)
#' @description Computes the classification matrix
#' @param data data frame (data table)
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two or more modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(candisc)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$RAZRED
#' disc_clasp <- disc_clas_p (DATA, x, g)
#' disc_clasp
disc_clas_p <- function(data, x, g){
  X <- as.matrix(x)
  var_disc <- MASS::lda(g ~ X, data)
  predict <- predict(var_disc)
  predict <- predict$class
  ctfp <- gmodels::CrossTable(predict, g)
  ctfp <- round(ctfp$prop.col*100, digits = 2)
  ctfp <- as.data.frame.matrix(t(ctfp))
  ctfp$Total = rowSums(ctfp[,])
  ctfp
}

#' @title Discriminative analysis - discrimination scores
#' @description Computes entity scores on discriminant functions
#' @param data data frame (data table)
#' @param x the data frame of the quantitative data
#' @param g qualitative variable with two or more modalities
#' @return dataframe
#' @export
#' @examples
#' library(rstatpackage)
#' library(dplyr)
#' library(candisc)
#' x <- DATA |> select_if(is.numeric)
#' g <- DATA$RAZRED
#' disc_score <- disc_score(DATA, x, g)
#' disc_score
disc_score <- function(data, x, g){
  X <- as.matrix(x)
  G <- as.matrix(g)
  m <- ncol(x)
  dfnames <- paste0("DF", 1:m)
  n <- nrow(x)
  var_disc <- lm(X ~ G, data = data)
  cd_candisc <- candisc::candisc(var_disc, data = data)
  k <- cd_candisc$ndim
  df1 <- cd_candisc$scores[1]
  df2 <- cd_candisc$scores[1:k+1]
  df2 <- round(df2, digits = 3)
  dfs <- cbind(df1, df2)
  colnames(dfs) <- c("Group", dfnames[1:k])
  dfs
}
